SURPRISE OKUNLOLA PUBLIC PROFILE
================================

Files:
- index.html — the main public biography page
- profile.jpg — add your preferred professional photo with this exact filename

BEFORE PUBLISHING
1. Replace YOUR-DOMAIN-HERE with your real website/domain.
2. Replace PASTE-YOUR-LINKEDIN-URL-HERE with your exact LinkedIn profile URL.
3. Put your professional photo in this folder and name it profile.jpg.
4. Upload the files to your website hosting.

IMPORTANT
This page is designed to give Google a clear, crawlable public source about you.
Publishing it does not guarantee a Google Knowledge Panel or immediate ranking.
After publishing, submit the URL through Google Search Console and request indexing.
Keep your name, education, leadership titles and other factual details consistent
across your public profiles.
